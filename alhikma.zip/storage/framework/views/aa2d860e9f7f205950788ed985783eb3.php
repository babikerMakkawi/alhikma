

<?php $__env->startSection('content'); ?>
    <main id="main" dir="rtl">
        <section id="breadcrumbs" class="breadcrumbs">
            <div class="container">
                <div class="d-flex justify-content-between align-items-center">
                    <h2 class=" wow animate__animated animate__fadeInRight">النشر الإلكتروني</h2>
                    <ol class=" wow animate__animated animate__fadeInLeft">
                        <li><a href="/">الرئيسية</a></li>
                        <li>النشر الإلكتروني</li>
                    </ol>
                </div>
            </div>
        </section>

        <!--  -->

        <section id="about" class="about" dir="rtl">
            <div class="container">
                <div class="row content">
                    <div class="col-lg-12">
                        <div class="row">
                            <div class="col-12">
                                <div class="card bg-light  wow animate__animated animate__fadeInLeft">
                                    <div class="card-header">
                                        <form action="<?php echo e(route('electronic-publishing')); ?>" method="GET"
                                            class="form-inline">
                                            <div class="input-group">
                                                <input type="text" name="search"
                                                    class="form-control rounded-0 rounded-end-3" placeholder="بحث"
                                                    value="<?php echo e(app('request')->input('search')); ?>">
                                                <select name="sort_by" class="form-control">
                                                    <option value="title"
                                                        <?php echo e(app('request')->input('sort_by') == 'title' ? 'selected' : ''); ?>>
                                                        عنوان البحث</option>
                                                    <option value="researcher"
                                                        <?php echo e(app('request')->input('sort_by') == 'researcher' ? 'selected' : ''); ?>>
                                                        إسم الباحث</option>
                                                    <option value="number_of_pages"
                                                        <?php echo e(app('request')->input('sort_by') == 'number_of_pages' ? 'selected' : ''); ?>>
                                                        عدد الصفحات</option>
                                                    <option value="date"
                                                        <?php echo e(app('request')->input('sort_by') == 'date' ? 'selected' : ''); ?>>
                                                        التاريخ</option>
                                                </select>
                                                <select name="sort_order" class="form-control">
                                                    <option value="asc"
                                                        <?php echo e(app('request')->input('sort_order') == 'asc' ? 'selected' : ''); ?>>
                                                        تصاعدي</option>
                                                    <option value="desc"
                                                        <?php echo e(app('request')->input('sort_order') == 'desc' ? 'selected' : ''); ?>>
                                                        تنازلي</option>
                                                </select>
                                                <button type="submit"
                                                    class="btn btn-sm btn-primary rounded-0 rounded-start-3">
                                                    <i class="fa fa-search" aria-hidden="true"></i>
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="card-body">
                                        <table class="table">
                                            <thead class="thead-light">
                                                <tr>
                                                    <th scope="col">#</th>
                                                    <th scope="col">عنوان البحث</th>
                                                    <th scope="col">إسم الباحث</th>
                                                    <th scope="col">عدد الصفحات</th>
                                                    <th scope="col">تاريخ النشر</th>
                                                    <th scope="col">عرض الملف</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $researches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $research): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <th scope="row"><?php echo e($research->id); ?></th>
                                                        <td><?php echo e($research->title); ?></td>
                                                        <td><?php echo e($research->researcher); ?></td>
                                                        <td><?php echo e($research->number_of_pages); ?></td>
                                                        <td><?php echo e($research->date); ?></td>
                                                        <td>
                                                            <a href="storage/app/public/uploads/<?php echo e($research->file); ?>"
                                                                target="_blank" class="btn btn-primary btn-sm">عرض</a>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td colspan="6">
                                                            <small class="text-center w-100 d-block">
                                                                لا يوجد بحوث في الوقت الحالي
                                                            </small>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>

                                        <div dir="ltr">
                                            <?php echo e($researches->appends([
                                                    'search' => request()->input('search'),
                                                    'sort_by' => request()->input('sort_by'),
                                                    'sort_order' => request()->input('sort_order'),
                                                ])->onEachSide(5)->links()); ?>

                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </section>

    </main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\UST\Github\alhikma\resources\views/electronic-publishing.blade.php ENDPATH**/ ?>