

<?php $__env->startSection('content'); ?>
    <main id="main" dir="rtl">
        <section id="breadcrumbs" class="breadcrumbs">
            <div class="container">
                <div class="d-flex justify-content-between align-items-center">
                    <h2 class=" wow animate__animated animate__fadeInRight">إدارة فهرس كشاف المجلة</h2>
                    <ol class=" wow animate__animated animate__fadeInLeft">
                        <li><a href="/">الرئيسية</a></li>
                        <li>إدارة فهرس كشاف المجلة</li>
                    </ol>
                </div>
            </div>
        </section>

        <!--  -->

        <section id="about" class="about" dir="rtl">
            <div class="container">
                <div class="row content">
                    <div class="col-lg-12">
                        <div class="row">
                            <div class="col-12">
                                
                                <?php if($message = Session::get('success')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php endif; ?>

                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>

                                
                                <div class="card bg-light  wow animate__animated animate__fadeInLeft">
                                    <div class="card-header d-flex justify-content-between">

                                        <form action="<?php echo e(route('researchesIndex.index')); ?>" method="GET"
                                            class="form-inline">
                                            <div class="input-group">

                                                
                                                <input type="text" name="search"
                                                    class="form-control rounded-0 rounded-end-3" placeholder="بحث"
                                                    value="<?php echo e(app('request')->input('search')); ?>">

                                                
                                                <select name="sort_by" class="form-control">
                                                    <option value="subject"
                                                        <?php echo e(app('request')->input('sort_by') == 'subject' ? 'selected' : ''); ?>>
                                                        الموضوع
                                                    </option>
                                                    <option value="title"
                                                        <?php echo e(app('request')->input('sort_by') == 'title' ? 'selected' : ''); ?>>
                                                        عنوان البحث
                                                    </option>
                                                    <option value="researcher"
                                                        <?php echo e(app('request')->input('sort_by') == 'researcher' ? 'selected' : ''); ?>>
                                                        إسم الباحث</option>
                                                    <option value="number"
                                                        <?php echo e(app('request')->input('sort_by') == 'number' ? 'selected' : ''); ?>>
                                                        العدد
                                                    </option>
                                                </select>

                                                
                                                <select name="sort_order" class="form-control">
                                                    <option value="asc"
                                                        <?php echo e(app('request')->input('sort_order') == 'asc' ? 'selected' : ''); ?>>
                                                        تصاعدي</option>
                                                    <option value="desc"
                                                        <?php echo e(app('request')->input('sort_order') == 'desc' ? 'selected' : ''); ?>>
                                                        تنازلي</option>
                                                </select>
                                                <button type="submit"
                                                    class="btn btn-sm btn-primary rounded-0 rounded-start-3">
                                                    <i class="fa fa-search" aria-hidden="true"></i>
                                                </button>
                                            </div>
                                        </form>


                                        <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                            data-bs-target="#exampleModal">
                                            إصافة بحث
                                            <i class="fa fa-plus" aria-hidden="true"></i>
                                        </button>

                                    </div>
                                    <div class="card-body">
                                        <table class="table">
                                            <thead class="thead-light">
                                                <tr>
                                                    <th scope="col">الموضوع</th>
                                                    <th scope="col">إسم البحث</th>
                                                    <th scope="col">إسم الباحث</th>
                                                    <th scope="col">العدد</th>
                                                    <th scope="col">التحكم</th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $research_index; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <td><?php echo e($index->subject); ?></td>
                                                        <td><?php echo e($index->title); ?></td>
                                                        <td><?php echo e($index->researcher); ?></td>
                                                        <td><?php echo e($index->number); ?></td>
                                                        <td>
                                                            <form method="post"
                                                                action="<?php echo e(route('researchesIndex.destroy', $index->id)); ?>"
                                                                onSubmit='return confirm("هل أنت متأكد؟")'
                                                                class="btn-group">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>

                                                                <button type="submit"
                                                                    class="btn btn-danger btn-sm rounded-0">
                                                                    <i class="fa fa-trash" aria-hidden="true"></i>
                                                                </button>
                                                            </form>

                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td colspan="6">
                                                            <small class="text-center w-100 d-block">
                                                                لا يوجد بحوث مفهرسة في الوقت الحالي
                                                            </small>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                        <div dir="ltr">
                                            
                                            <?php echo e($research_index->appends([
                                                    'search' => request()->input('search'),
                                                    'sort_by' => request()->input('sort_by'),
                                                    'sort_order' => request()->input('sort_order'),
                                                ])->links()); ?>


                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </section>

        
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">إنشاء بحث</h5>
                        <button type="button" class="btn btn-secondary pb-0 pt-1 px-2" data-bs-dismiss="modal"
                            aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form method="post" action="<?php echo e(route('researchesIndex.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">

                            
                            <div class="row mb-3">
                                <label class="col-sm-2 col-label-form">الموضوع</label>
                                <div class="col-sm-10">
                                    <input type="text" name="subject" value="<?php echo e(old('subject')); ?>"
                                        class="form-control" />
                                </div>
                            </div>

                            
                            <div class="row mb-3">
                                <label class="col-sm-2 col-label-form">عنوان البحث</label>
                                <div class="col-sm-10">
                                    <input type="text" name="title" value="<?php echo e(old('title')); ?>"
                                        class="form-control" />
                                </div>
                            </div>

                            
                            <div class="row mb-3">
                                <label class="col-sm-2 col-label-form">إسم الباحث</label>
                                <div class="col-sm-10">
                                    <input type="text" name="researcher" value="<?php echo e(old('researcher')); ?>"
                                        class="form-control" />
                                </div>
                            </div>

                            
                            <div class="row mb-3">
                                <label class="col-sm-2 col-label-form">العدد</label>
                                <div class="col-sm-10">
                                    <input type="text" name="number" value="<?php echo e(old('number')); ?>"
                                        class="form-control" />
                                </div>
                            </div>


                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                            <button type="submit" class="btn btn-primary">حفظ</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\UST\Github\alhikma\resources\views/dashboard/researchIndex/index.blade.php ENDPATH**/ ?>